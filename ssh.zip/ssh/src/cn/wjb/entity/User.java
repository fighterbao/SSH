package cn.wjb.entity;

import java.util.HashSet;
import java.util.Set;

public class User {
	
	private int uid;
	private String username;
	private String password;
	private String address;
	//一个用户里面的所有拜访记录
	private Set<Visit> setUserVisit = new HashSet<Visit>();
	
	public Set<Visit> getSetUserVisit() {
		return setUserVisit;
	}
	public void setSetUserVisit(Set<Visit> setUserVisit) {
		this.setUserVisit = setUserVisit;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	

}
