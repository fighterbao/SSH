package cn.wjb.entity;

import java.util.HashSet;
import java.util.Set;

public class Customer {
	
	private int uid;
	private String custName;
	private String custLevel;
	private String custSource;
	private String custPhone;
	private String custMobile;
	//一个客户里面的所有拜访记录
	private Set<Visit> setCustomerVisit = new HashSet<Visit>();
	//表示所有联系人,customer 1:n linkman
	private Set<LinkMan> linkman = new HashSet<LinkMan>();
	
	public Set<Visit> getSetCustomerVisit() {
		return setCustomerVisit;
	}
	public void setSetCustomerVisit(Set<Visit> setCustomerVisit) {
		this.setCustomerVisit = setCustomerVisit;
	}
	public Set<LinkMan> getLinkman() {
		return linkman;
	}
	public void setLinkman(Set<LinkMan> linkman) {
		this.linkman = linkman;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustLevel() {
		return custLevel;
	}
	public void setCustLevel(String custLevel) {
		this.custLevel = custLevel;
	}
	public String getCustSource() {
		return custSource;
	}
	public void setCustSource(String custSource) {
		this.custSource = custSource;
	}
	public String getCustPhone() {
		return custPhone;
	}
	public void setCustPhone(String custPhone) {
		this.custPhone = custPhone;
	}
	public String getCustMobile() {
		return custMobile;
	}
	public void setCustMobile(String custMobile) {
		this.custMobile = custMobile;
	}
	

}