package cn.wjb.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import cn.wjb.dao.CustomerDao;
import cn.wjb.entity.Customer;
import cn.wjb.entity.PageBean;

@Transactional
public class CustomerService {
	
	private CustomerDao customerDao;

	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
	}

	public void save(Customer customer) {
		
		customerDao.save(customer);
		
	}

	public List<Customer> findAll() {
		
		return customerDao.findAll();
		
	}

	public Customer findOne(int uid) {
		
		return customerDao.findOne(uid);
	}

	public void delete(Customer c) {
		
		customerDao.delete(c);
		
	}

	public void update(Customer customer) {
	
		customerDao.update(customer);
	}

	public PageBean pagelist(Integer currentPage) {
		
		PageBean pagebean = new PageBean();
		//当前页
		pagebean.setCurrentPage(currentPage);
		//总记录数
		int totalCount = customerDao.findCount();
		pagebean.setTotalCount(totalCount);
		//每页显示记录数
		int pageSize = 3;
		//总页数
		int totalPage = 0;
		if(totalCount%pageSize==0){
			totalPage=totalCount/pageSize;
		}else{
			totalPage=totalCount/pageSize+1;
		}
		pagebean.setTotalPage(totalPage);
		//开始位置
		int begin = (currentPage-1)*pageSize;
		//每页记录的list集合
		List<Customer> list = customerDao.findPage(begin,pageSize);
		pagebean.setList(list);
		
		return pagebean;
	}

	public List<Customer> search(String custName) {
		return customerDao.search(custName);
	}


	

}
