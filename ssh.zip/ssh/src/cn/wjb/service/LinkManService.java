package cn.wjb.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import cn.wjb.dao.LinkManDao;
import cn.wjb.entity.LinkMan;

@Transactional
public class LinkManService {
	
	private LinkManDao linkmanDao;

	public void setLinkmanDao(LinkManDao linkmanDao) {
		this.linkmanDao = linkmanDao;
	}

	public void add(LinkMan linkMan) {
		linkmanDao.add(linkMan);
		
	}

	public List<LinkMan> findAll() {
		
		return linkmanDao.findAll();
	}

	public LinkMan findOne(int uid) {
		
		return linkmanDao.findOne(uid);
	}

	public void update(LinkMan linkMan) {
		
		linkmanDao.update(linkMan);
		
	}
	

}
