package cn.wjb.dao;

import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import cn.wjb.entity.Visit;

public class VisitDaoImpl extends HibernateDaoSupport implements VisitDao {

	public void add(Visit visit) {
		this.getHibernateTemplate().save(visit);
		
	}

	public List<Visit> findAll() {
		
		return (List<Visit>) this.getHibernateTemplate().find("from Visit");
	}
	

}
