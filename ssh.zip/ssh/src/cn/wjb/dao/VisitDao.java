package cn.wjb.dao;

import java.util.List;

import cn.wjb.entity.Visit;

public interface VisitDao {

	void add(Visit visit);

	List<Visit> findAll();

}
