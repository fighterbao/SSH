package cn.wjb.dao;

import java.util.List;

import cn.wjb.entity.User;

public interface UserDao {

	User login(User user);

	List<User> findAll();

}
