package cn.wjb.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import cn.wjb.entity.Customer;
@SuppressWarnings("all")
public class CustomerDaoImpl extends HibernateDaoSupport implements CustomerDao {

	
	public void save(Customer customer) {
		this.getHibernateTemplate().save(customer);

	}

	public List<Customer> findAll() {
		List<Customer> list = (List<Customer>) this.getHibernateTemplate().find("from Customer");
		return list;
	}

	public Customer findOne(int uid) {
		List<Customer> list = (List<Customer>) this.getHibernateTemplate().find("from Customer where uid=?", uid);
		if(list!=null&&list.size()!=0){
			Customer c = list.get(0);
			return c;
		}
		return null;
	}
	
	public void delete(Customer c) {
		this.getHibernateTemplate().delete(c);

	}

	public void update(Customer customer) {
		this.getHibernateTemplate().update(customer);
	}

	public int findCount() {
		List<Object> list = (List<Object>) this.getHibernateTemplate().find("select count(*) from Customer");
		if(list!=null&&list.size()!=0){
			Object obj = list.get(0);
			//变成int型
			Long lobj = (Long) obj;
			int count = lobj.intValue();
			return count;
		}
		return 0;
	}

	public List<Customer> findPage(int begin, int pageSize) {
		//创建离线对象
		DetachedCriteria criteria = DetachedCriteria.forClass(Customer.class);
		List<Customer> list = (List<Customer>) this.getHibernateTemplate().findByCriteria(criteria, begin, pageSize);
		return list;
	}

	public List<Customer> search(String custName) {
		List<Customer> list = (List<Customer>) this.getHibernateTemplate().find("from Customer where custName like ?", "%"+custName+"%");
		return list;
	}

}
