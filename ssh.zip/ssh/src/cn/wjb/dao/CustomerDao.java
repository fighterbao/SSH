package cn.wjb.dao;

import java.util.List;

import cn.wjb.entity.Customer;
import cn.wjb.entity.User;

public interface CustomerDao {

	void save(Customer customer);

	List<Customer> findAll();

	Customer findOne(int uid);

	void delete(Customer c);

	void update(Customer customer);
	
	int findCount();

	List<Customer> findPage(int begin, int pageSize);

	List<Customer> search(String custName);

	

}
