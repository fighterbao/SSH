package cn.wjb.dao;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import cn.wjb.entity.User;

public class UserDaoImpl extends HibernateDaoSupport implements UserDao {

	@SuppressWarnings("all")
	public User login(User user) {
		
		HibernateTemplate hibernate = this.getHibernateTemplate();
		List<User> list = (List<User>) hibernate.find("from User where username=? and password=?", user.getUsername(),user.getPassword());
		if(list!=null&&list.size()!=0){
			User u = list.get(0);
			return u;
		}
		return null;
		
	}

	public List<User> findAll() {
		return (List<User>) this.getHibernateTemplate().find("from User");
		 
	}

}
