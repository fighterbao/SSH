package cn.wjb.dao;

import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import cn.wjb.entity.LinkMan;

public class LinkManDaoImpl extends HibernateDaoSupport implements LinkManDao {

	public void add(LinkMan linkMan) {
		this.getHibernateTemplate().save(linkMan);
	}

	@SuppressWarnings("all")
	public List<LinkMan> findAll() {
		
		return (List<LinkMan>) this.getHibernateTemplate().find("from LinkMan");
	}

	public LinkMan findOne(int uid) {
		
		return this.getHibernateTemplate().get(LinkMan.class, uid);
	}

	public void update(LinkMan linkMan) {
		
		this.getHibernateTemplate().update(linkMan);
		
	}

}
