package cn.wjb.dao;

import java.util.List;

import cn.wjb.entity.LinkMan;

public interface LinkManDao {

	void add(LinkMan linkMan);

	List<LinkMan> findAll();

	LinkMan findOne(int uid);

	void update(LinkMan linkMan);

}
