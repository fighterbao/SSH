package cn.wjb.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import cn.wjb.entity.Customer;
import cn.wjb.entity.User;
import cn.wjb.entity.Visit;
import cn.wjb.service.CustomerService;
import cn.wjb.service.UserService;
import cn.wjb.service.VisitService;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class VisitAction extends ActionSupport implements ModelDriven<Visit> {
	
	private Visit visit = new Visit();
	public Visit getModel() {
		return visit;
	}
	
	private VisitService visitService;
	public void setVisitService(VisitService visitService) {
		this.visitService = visitService;
	}
	
	private UserService userService;
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	
	private CustomerService customerService;
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}


	public String toAdd(){
		//查询所有用户
		List<User> listu = userService.findAll();
		//查询所有客户
		List<Customer> listc = customerService.findAll();
		//放入域对象
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setAttribute("listu", listu);
		request.setAttribute("listc", listc);
		return "toadd";
	}
	
	public String add(){
		visitService.add(visit);
		return "add";
	}
	
	public String list(){
		List<Visit> list = visitService.findAll();
		ServletActionContext.getRequest().setAttribute("list", list);
		return "list";
	}


	
	

}
