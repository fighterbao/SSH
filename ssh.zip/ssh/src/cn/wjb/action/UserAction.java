package cn.wjb.action;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import cn.wjb.entity.User;
import cn.wjb.service.UserService;

import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {
	
	private UserService userService;
	
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	private String username;
	private String password;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}


	public String login(){
		//分装实体类对象
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		
		//调用service层
		User fuser = userService.login(user);
		
		if(fuser!=null){
			//使用session保持登录状态
			HttpServletRequest request = ServletActionContext.getRequest();
			request.getSession().setAttribute("user",fuser);
			return "success";
		}else{
			return "login";
		}
	}

}
