package cn.wjb.action;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import cn.wjb.entity.Customer;
import cn.wjb.entity.LinkMan;
import cn.wjb.service.CustomerService;
import cn.wjb.service.LinkManService;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class LinkManAction extends ActionSupport implements ModelDriven<LinkMan>{
	
	//模型驱动
	private LinkMan linkMan = new LinkMan();
	public LinkMan getModel() {
		return linkMan;
	}
	
	private LinkManService linmanService;
	public void setLinmanService(LinkManService linmanService) {
		this.linmanService = linmanService;
	}
	
	//注入客户service对象
	private CustomerService customerService;
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}


	public String toAdd(){
		//查询所有客户，把list放入域对象
		List<Customer> list = customerService.findAll();
		ServletActionContext.getRequest().setAttribute("list", list);
		return "toadd";
	}
	
	/*
	 * 需要上传文件名称
	 * 1.在action里面成员变量位置定义变量（命名规范）
	 * 一个表示上传文件
	 * 一个表示文件名称
	 * 2.生成get,set方法
	 * */
	private File upload;//变量名称是表单里上传项name的值
	private String uploadFileName;//name值加FileName
	public File getUpload() {
		return upload;
	}
	public void setUpload(File upload) {
		this.upload = upload;
	}
	public String getUploadFileName() {
		return uploadFileName;
	}
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}


	public String add() throws Exception{
		
		if(upload!=null){
			//在服务器里创建文件夹
			File serverFile = new File("F:\\1"+"/"+uploadFileName);
			//把上传文件复制到服务器
			FileUtils.copyFile(upload, serverFile);
		}
		
		linmanService.add(linkMan);
		return "add";
	}
	
	public String list(){
		List<LinkMan> list = linmanService.findAll();
		ServletActionContext.getRequest().setAttribute("list", list);
		return "list";
	}
	
	public String edit(){
		int uid= linkMan.getUid();
		LinkMan linkf = linmanService.findOne(uid);
		List<Customer> listc = customerService.findAll();
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setAttribute("linkf", linkf);
		request.setAttribute("listc", listc);
		
		return "edit";
	}
	
	public String update(){
		linmanService.update(linkMan);
		return "update";
	}


	
	

}
