package cn.wjb.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import cn.wjb.entity.Customer;
import cn.wjb.entity.PageBean;
import cn.wjb.service.CustomerService;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class CustomerAction extends ActionSupport implements ModelDriven<Customer>{
	
	//模型驱动
	private Customer customer = new Customer();
	public Customer getModel() {
		
		return customer;
	}
	
	private CustomerService customerService;
	
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}
	
	//属性封装
	private Integer currentPage;
	public Integer getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	//分页查询
	public String pageList(){
			
		PageBean pageb = customerService.pagelist(currentPage);	
		//放入域对象
		ServletActionContext.getRequest().setAttribute("pageb", pageb);
		return "pagelist";
	}

	public String toAdd(){
		
		return "add";
	}
	
	public String save(){
		
		customerService.save(customer);
		
		return "save";
	}

	
	public String list(){
		
		List<Customer> list = customerService.findAll();
		
		ServletActionContext.getRequest().setAttribute("list", list);
		
		return "list";
		
	}
	
	public String delete(){
		int uid=customer.getUid();
		Customer c = customerService.findOne(uid);
		customerService.delete(c);
		return "delete";
	}
	
	public String edit(){
		
		int uid=customer.getUid();
		Customer c = customerService.findOne(uid);
		
		ServletActionContext.getRequest().setAttribute("cust", c);
		
		return "edit";
	}
	
	public String update(){
		
		customerService.update(customer);
		
		return "update";
	}
	
	//条件搜索
	public String search(){
		
		if(customer.getCustName()!=null&&!"".equals(customer.getCustName())){
			List<Customer> list = customerService.search(customer.getCustName());
			ServletActionContext.getRequest().setAttribute("list", list);
		}
		else{
			list();
		}
		return "search";
	}

}
